cowsay -f meow "Ntaps" | lolcat
