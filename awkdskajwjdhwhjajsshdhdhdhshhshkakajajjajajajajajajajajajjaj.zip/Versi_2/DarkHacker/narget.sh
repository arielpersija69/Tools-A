cowsay -f bong "Hacker" | lolcat
