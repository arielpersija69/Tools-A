clear
blue='\033[1;34m'
green='\033[1;32m'
purple='\033[1;35m'
cyan='\033[1;36m'
red='\033[1;31m'
white='\033[1;37m'
yellow='\033[1;33m'
NOW=`date "+%d.%m.%Y"`
TIME=`date "+%H:%M"`
date | lolcat
echo
sleep 1
echo
toilet -f big -F gay MR.AsP
echo $red"Selamat Datang Kak"
echo
sleep 2
echo $blue"Pilih Tools Yang Tersedia Kak : "
echo
echo $yellow"1.) Dark Fb By Ariel"
echo
echo $purple"2.) Dark Fb Anak Bangsa"
echo
echo $red"3.) Sadap Kamera"
echo
echo $white"4.) Hack Facebook Brute Force"
echo
echo $cyan"5.) Tombol Kanan Kiri"
echo
echo $green"6.) Spamm Telepon"
echo
echo $blue"7.) Membuat Script Deface"
echo
echo $green"8.) Spam WhatsApp"
echo
echo $red"9.) 57 Tools"
echo
echo $white"10.) 290 Tools"
echo
echo $red"11.) Dark Meow"
echo 
echo $blue"12.) Dark Hacker"
echo
echo $green"13.) Dark BugHunter"
echo
echo $blue"14.) Dark Fb Cepet 1000000%"
echo
echo $green"0.) Exit"
echo
echo $white
read -p "Pilih Tools Nya Kak : " bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
toilet -f big -F gay MR.Asp
echo $blue"Dark Fb By Ariel"
git clone https://github.com/arielpersija69/workanjng
cd workanjng
python2 WorkBangsat.py
fi

if [ $bro = 2 ] || [ $bro = 2 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo $blue"Dark Fb By Anak Bangsa"
cd /sdcard/Download
cd Versi_2
python2 Apriyani_Kapan_Peka_Anjing
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo $green"Sadap Kamera"
git clone https://github.com/thelinuxchoice/saycheese
cd saycheese
bash saycheese.sh
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo $yellow"BruteForce"
git clone https://github.com/sixtysix-Team/fbbrute
cd fbbrute
python2 force.py
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo $green"z"
git clone https://github.com/arielpersija69/Xxx
cd Xxx
python2 terkey.py
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo $blue"v"
git clone https://github.com/siputra12/prank
cd prank
php call.php
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo $white"gas"
cd /sdcard/Download
cd Sad
cd Ariel
python2 Ariel.py
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
cowsay -f dragon Gua Ganteng :v | lolcat
toilet -f big "Indonesia Lite" -F gay
echo "dah"
git clone https://github.com/siputra12/prank
cd prank
php wa.php
fi

if [ $bro = 9 ] || [ $bro = 9 ]
then
clear
toilet -f big "Ariel :(" -F gay
echo "."
git clone https://github.com/Rusmana-ID/rus
cd rus
sh v2.sh
fi

if [ $bro = 14 ] || [ $bro = 14 ]
then
clear
toilet -f big "KONTOL ITU BERBATANG" -F gay
cd /sdcard/Download
cd Versi_2
python2 ArielGanteng
fi

if [ $bro = 10 ] || [ $bro = 10 ]
then
clear
toilet -f big "Subscribe" -F gay
cd /sdcard/Download
cd Versi_2
sh Ariel.sh
fi

if [ $bro = 11 ] || [ $bro = 11 ]
then
clear
toilet -f big "Dark Meow" -F gay
cd DarkMeow
python2 DarkMeow
fi

if [ $bro = 12 ] || [ $bro = 12 ]
then
clear
toilet -f big "Dark Hacker" -F gay
cd DarkHacker
python2 DarkHackerByAriel
fi

if [ $bro = 13 ] || [ $bro = 13 ]
then
clear
toilet -f big "Dark BugHunters" -F gay
cd a
python2 BugHunters
fi

if [ $bro = 0 ] || [ $bro = 0 ]
then
clear
echo $green
figlet "Subcribe Ariel 69 Channel"
echo $blue"Dah"
sleep 3
exit
fi
