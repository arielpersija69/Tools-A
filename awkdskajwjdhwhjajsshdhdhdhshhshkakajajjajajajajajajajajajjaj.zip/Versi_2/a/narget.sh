cowsay -f tux "BUG HUNTERS" | lolcat
figlet "BUG HUNTERS" | lolcat